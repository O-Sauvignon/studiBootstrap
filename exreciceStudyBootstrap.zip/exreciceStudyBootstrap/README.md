écriture du code puis dépot sur git
https://github.com/O-Sauvignon/studiBootstrap
déploiment en sous domaine chez IONOS mon hebergeur
http://studibootstrap.oswebetique.com